import React from 'react'
import Weatherpage from './components/Weatherpage'
import './App.css'; 

const App = () => {
  return (
    <div>
      <Weatherpage/>
    </div>
  )
}

export default App
